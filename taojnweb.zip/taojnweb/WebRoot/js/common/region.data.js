var regions = [{
	id : '001',
	text : '境内(中国)',
	state : 'closed',
	children : [{
		id : '001001',
		text : '浙江',
		state : 'closed',
		children : [{
			id : '001001001',
			text : '杭州'
		}, {
			id : '001001002',
			text : '宁波'
		}, {
			id : '001001003',
			text : '温州'
		}]
	}]
}, {
	id : '000',
	text : '境外',
	state : 'closed',
	children : [{
		id : '002',
		text : '美国'
	}, {
		id : '003',
		text : '英国'
	}, {
		id : '004',
		text : '日本'
	}, {
		id : '005',
		text : '意大利'
	}]
}];
