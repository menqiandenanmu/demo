//全局静态变量
var applicationContent={}
applicationContent.content=$("meta[name=content]")
applicationContent.baseUrl=applicationContent.content.attr("baseUrl");
applicationContent.backUrl=applicationContent.content.attr("backUrl");